<?php return array (
  'auth.header.user-profile' => 'App\\Http\\Livewire\\Auth\\Header\\UserProfile',
  'auth.header.user-profile-mobile' => 'App\\Http\\Livewire\\Auth\\Header\\UserProfileMobile',
);