<?php
return [
    'host' => env('MAPCREATOR_HOST'),
    'client_id' => env('MAPCREATOR_CLIENT_ID'),
    'client_secret' => env('MAPCREATOR_CLIENT_SECRET'),
];
