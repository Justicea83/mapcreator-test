<template>
    <h1>Welcome Justice from vue</h1>
</template>

<script>
export default {
    name: "Welcome"
}
</script>

<style scoped>

</style>
