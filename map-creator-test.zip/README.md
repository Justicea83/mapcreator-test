## Home to run this application locally.

- Run `npm install`
- Run `composer install`
- Ensure docker desktop is running
- Run `vendor/bin/sail artisan migrate`
- Run `vendor/bin/sail artisan db:seed`
