<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8"><!---->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>MapCreator Test | <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body class="antialiased">

<div class="min-h-full">
    <?php echo $__env->make('auth.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="py-10">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/auth.blade.php ENDPATH**/ ?>